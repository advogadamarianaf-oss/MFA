# 📥 Como importar o Notion Adv para o Notion

Você recebeu **11 bancos de dados** (arquivos `.csv`) e **3 páginas** (arquivos `.md`). Siga os passos abaixo.

---

## Passo 1 — Importar as páginas (Markdown)

1. No Notion, abra a página onde quer criar o sistema (ex.: uma página chamada "Notion Adv").
2. Clique nos **`...`** no canto superior direito → **Import** → **Markdown & CSV** (ou **Text & Markdown**).
3. Selecione os arquivos:
   - `00_INICIO_Notion_Adv.md` → vira a página inicial / hub.
   - `12_Modelos_de_Peticoes.md` → banco de modelos.
   - `LEIA-ME_Importacao.md` → este guia.

---

## Passo 2 — Importar os bancos de dados (CSV)

1. Na mesma página, clique em **Import** → **CSV**.
2. Selecione **todos os arquivos `.csv`** de uma vez (de `01_` a `11_`).
3. Cada arquivo vira um **banco de dados (database)** separado, com as colunas já como propriedades.

> 💡 O Notion importa tudo como texto. Depois da importação, ajuste o **tipo de cada propriedade** (passo 3).

---

## Passo 3 — Ajustar os tipos de propriedade

Em cada banco, clique no cabeçalho da coluna → **Edit property** → escolha o tipo:

| Coluna | Tipo recomendado |
| --- | --- |
| Status, Etapa, Fase, Prioridade, Tipo | **Select** |
| Tags, Área | **Multi-select** |
| Datas (Vencimento, Prazo, Data Fatal) | **Date** |
| Valor, Valor da Causa | **Number** (formato R$) |
| E-mail | **Email** |
| Telefone | **Phone** |
| Responsável, Advogado | **Person** ou **Select** |
| Link/Anexo | **URL** ou **Files & media** |

---

## Passo 4 — Conectar os bancos (Relations)

Para o sistema funcionar de forma integrada, crie propriedades do tipo **Relation**:

- `Processos` → relacionar com `Clientes`
- `Prazos` → relacionar com `Processos`
- `Audiências` → relacionar com `Processos`
- `Diligências` → relacionar com `Processos`
- `Tarefas` → relacionar com `Clientes` ou `Processos`
- `Financeiro` → relacionar com `Clientes`
- `Documentos` → relacionar com `Clientes` e `Processos`

> Depois das *Relations*, use **Rollup** para puxar informações automaticamente (ex.: ver todos os prazos de um cliente direto na ficha dele).

---

## Passo 5 — Criar as visualizações

Veja as sugestões na página `00_INICIO_Notion_Adv.md` (seção "Visualizações recomendadas"): Calendário para prazos/audiências, Kanban para funil e tarefas, e somatório no financeiro.

---

✅ **Pronto!** Seu escritório digital está montado. Tudo é editável — adapte campos, cores e filtros ao seu fluxo.
