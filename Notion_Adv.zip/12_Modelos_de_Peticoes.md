# 🗂 Modelos de Petições e Requerimentos

Banco de modelos prontos para copiar, colar e adaptar. Substitua os campos entre **[colchetes]** pelos dados do caso.

---

## 📄 Procuração Ad Judicia et Extra

> **OUTORGANTE:** [Nome do cliente], [nacionalidade], [estado civil], [profissão], portador do RG nº [___] e inscrito no CPF nº [___], residente e domiciliado em [endereço completo].
>
> **OUTORGADO:** [Nome do advogado], inscrito na OAB/[UF] sob o nº [___], com escritório em [endereço].
>
> **PODERES:** Pelo presente instrumento, o outorgante nomeia e constitui seu bastante procurador o outorgado, conferindo-lhe os poderes da cláusula *ad judicia et extra*, para o foro em geral, em qualquer juízo, instância ou tribunal, podendo propor contra quem de direito as ações cabíveis e defendê-lo nas contrárias, bem como os poderes especiais para receber citação, confessar, reconhecer a procedência do pedido, transigir, desistir, renunciar ao direito sobre o qual se funda a ação, receber, dar quitação, firmar compromisso e substabelecer.
>
> [Cidade], [data].
>
> ______________________________
> [Nome do outorgante]

---

## 📄 Petição Inicial (estrutura básica)

> **EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA ___ VARA [CÍVEL/TRABALHISTA/FAMÍLIA] DA COMARCA DE [___]**
>
> **[NOME DO AUTOR]**, já qualificado, por seu advogado que esta subscreve, vem respeitosamente à presença de Vossa Excelência propor a presente
>
> **AÇÃO DE [___]**
>
> em face de **[NOME DO RÉU]**, [qualificação], pelos fatos e fundamentos a seguir expostos:
>
> **I – DOS FATOS**
> [Narrar os fatos de forma clara e cronológica.]
>
> **II – DO DIREITO**
> [Fundamentação jurídica, com artigos de lei e jurisprudência.]
>
> **III – DOS PEDIDOS**
> Ante o exposto, requer:
> a) A citação do réu;
> b) A procedência total dos pedidos para [___];
> c) A condenação do réu ao pagamento de custas e honorários advocatícios;
> d) A produção de todas as provas em direito admitidas.
>
> Dá-se à causa o valor de R$ [___].
>
> Nestes termos, pede deferimento.
> [Cidade], [data].
>
> [Nome do advogado] – OAB/[UF] [___]

---

## 📄 Contestação (estrutura básica)

> **EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA ___ VARA [___]**
>
> Processo nº [___]
>
> **[NOME DO RÉU]**, já qualificado nos autos da ação em epígrafe que lhe move **[NOME DO AUTOR]**, vem apresentar
>
> **CONTESTAÇÃO**
>
> pelas razões de fato e de direito a seguir:
>
> **I – DAS PRELIMINARES**
> [Ex.: ilegitimidade, inépcia da inicial, prescrição.]
>
> **II – DO MÉRITO**
> [Impugnação específica dos fatos narrados na inicial.]
>
> **III – DOS PEDIDOS**
> Requer a improcedência total dos pedidos, com a condenação do autor ao pagamento das custas e honorários.
>
> Nestes termos, pede deferimento.
> [Cidade], [data].
> [Nome do advogado] – OAB/[UF] [___]

---

## 📄 Requerimento Simples

> **EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) [___]**
>
> Processo nº [___]
>
> **[NOME DA PARTE]**, já qualificado, vem requerer a Vossa Excelência [descrever o pedido: ex. juntada de documento, designação de audiência, expedição de alvará].
>
> Nestes termos, pede deferimento.
> [Cidade], [data].
> [Nome do advogado] – OAB/[UF] [___]

---

## 📄 Petição de Juntada de Documentos

> **Processo nº [___]**
>
> **[NOME DA PARTE]**, nos autos em epígrafe, vem respeitosamente juntar aos autos os documentos anexos ([listar documentos]), requerendo sua apreciação por Vossa Excelência.
>
> Termos em que pede deferimento.
> [Cidade], [data].

---

## 📄 Modelo de Notificação Extrajudicial

> **NOTIFICAÇÃO EXTRAJUDICIAL**
>
> **Notificante:** [Nome/qualificação]
> **Notificado:** [Nome/qualificação]
>
> Pelo presente instrumento, o notificante vem NOTIFICAR Vossa Senhoria para que, no prazo de [___] dias, [descrever a providência exigida], sob pena de adoção das medidas judiciais cabíveis.
>
> [Cidade], [data].
> ______________________________
> [Nome do notificante / advogado]

---

> 💡 **Dica:** No Notion, transforme cada modelo numa página própria dentro de um banco de dados "Modelos" com as propriedades *Área*, *Tipo* e *Tags*. Assim você filtra rapidamente por matéria.
