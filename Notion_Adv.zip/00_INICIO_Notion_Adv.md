# ⚖️ Notion Adv — Sistema de Gestão Jurídica

> Central de comando do seu escritório de advocacia. Organize clientes, prazos, processos, equipe e finanças em um só lugar.

---

## 🧭 Navegação Rápida

| Módulo | O que controla |
| --- | --- |
| 📁 **Clientes** | Cadastro, histórico e dados de contato |
| ⚖️ **Processos** | Acompanhamento processual completo |
| 📅 **Prazos** | Prazos fatais, processuais e recursais |
| 🏛 **Audiências** | Agenda de audiências (presenciais e virtuais) |
| 🚶 **Diligências** | Protocolos, cartório, oficial de justiça |
| ✅ **Tarefas** | Lista de afazeres da equipe |
| 🧠 **Equipe** | Advogados, estagiários e colaboradores |
| 🤝 **Reuniões** | Agenda de reuniões internas e com clientes |
| 💰 **Financeiro** | Honorários, RPVs, entradas e saídas |
| 🗂 **Documentos** | Procurações, contratos e provas |
| 🎯 **Funil de Atendimento** | Captação e conversão de leads |
| 📄 **Modelos de Petições** | Banco de modelos prontos |

---

## 🚀 Como começar

1. **Importe os arquivos** seguindo o guia em `LEIA-ME_Importacao.md`.
2. **Conecte os bancos de dados** criando propriedades do tipo *Relation* (ex.: ligar `Prazos` → `Processos` → `Clientes`).
3. **Personalize as visualizações:** crie um *Calendar view* para Prazos e Audiências, e um *Board (Kanban)* para o Funil de Atendimento e Tarefas.
4. **Adapte os campos** ao seu fluxo de trabalho — tudo é 100% personalizável.

---

## 💡 Visualizações recomendadas no Notion

- 📅 **Prazos** → *Calendar* por "Data Fatal" + *Table* filtrada por "Status = Pendente".
- 🏛 **Audiências** → *Calendar* por "Data" + agrupar por "Advogado Responsável".
- 🎯 **Funil de Atendimento** → *Board* agrupado por "Etapa".
- ✅ **Tarefas** → *Board* agrupado por "Status" + filtro por "Responsável".
- 💰 **Financeiro** → *Table* com *Sum* na coluna "Valor" + agrupar por "Tipo" (Entrada/Saída).
- 📁 **Clientes** → *Gallery* ou *Table* filtrada por "Status = Ativo".

---

## 🔁 Automação leve (sugestões)

- Use **filtros salvos** para ver só o que vence esta semana.
- Crie uma propriedade *Formula* em Prazos para calcular "Dias Restantes" automaticamente:
  `dateBetween(prop("Data Fatal"), now(), "days")`
- Use **Reminders** do Notion (digite `@remind`) nas datas de prazo e audiência.
- Conecte bancos por *Relation* + *Rollup* para puxar dados do cliente direto no processo.

---

*Notion Adv • Modelo desenvolvido para advogados autônomos e escritórios com equipe.*
